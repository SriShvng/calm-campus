import { SignUp } from "@clerk/nextjs";
 // sign-up form
export default function Page() {
  return <SignUp />;
}